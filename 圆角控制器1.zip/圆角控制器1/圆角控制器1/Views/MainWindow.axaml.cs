using Avalonia;  
using Avalonia.Controls;  
using Avalonia.Markup.Xaml;  

namespace 圆角控制器1 
{  
    public partial class MainWindow : Window  
    {  
        public MainWindow()  
        {  
            InitializeComponent();  

            // 使窗口可移动  
            this.PointerPressed += MainWindow_PointerPressed;  
        }  

        private void InitializeComponent()  
        {  
            AvaloniaXamlLoader.Load(this);  
        }  

        private void CloseButton_Click(object sender, Avalonia.Interactivity.RoutedEventArgs e)  
        {  
            Close();  
        }  

        private void MainWindow_PointerPressed(object sender, Avalonia.Input.PointerPressedEventArgs e)  
        {  
            // 允许窗口被拖动  
            this.BeginMoveDrag(e);  
        }  
    }  
}
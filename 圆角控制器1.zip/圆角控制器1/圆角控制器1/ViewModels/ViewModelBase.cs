﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace 圆角控制器1.ViewModels;

public class ViewModelBase : ObservableObject
{
}